
  # Client Side PMO Dashboard V1

  This is a code bundle for Client Side PMO Dashboard V1. The original project is available at https://www.figma.com/design/BLrO1i29yyTrkkg4iyVR5V/Client-Side-PMO-Dashboard-V1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  