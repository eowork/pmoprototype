export { ClientPoliciesPage as default } from './ClientPoliciesPage';
export * from './types';
export * from './policiesData';